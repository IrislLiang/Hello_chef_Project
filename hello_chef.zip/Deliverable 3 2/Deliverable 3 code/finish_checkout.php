<?php
session_start();
?>

<html>
  <head>
        <h3 style="text-align:center;color: #111; font-family: 'Open Sans', sans-serif; font-size: 50px; font-weight: 300; line-height: 32px; margin: 0 0 72px; text-align: center; " >
    <?php echo $_SESSION['username'];?> 
    </h3>
    <style>
  .btn {
  border: 2px solid black;
  background-color: white;
  color: black;
  padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;
}

.success {
  border-color: #4CAF50;
  color: green;
}

.success:hover {
  background-color: #4CAF50;
  color: white;
}
    </style>
  </head>
  <body>
   <img src="thanks.png" alt="thanks" style="margin-left:300px; width:60%" ><br><br>
    <button class="btn success" onclick= "location.href='confirmedLogin.php'" style="margin-left:630px">View More Item</button>
  </body>
</html>