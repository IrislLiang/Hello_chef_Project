<?php
session_start();
?>

<html>
  

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="home_page.css">
</head>
<body>
<img alt="Company logo" src="newLogo.png" style="width:125px;height:125px">
 
  
  <form id="form1" name="form1" method="post" action="display.php" style="float:right;margin-top:35px">
<input name="submit" type="image" value="ee" src="user.jpeg" style="height:60px;width:60px;" />
</form>
  
<button onclick="location.href='logout.php'" style="width:auto; position:absolute;right:100px;top:50px;float:right">Log Out</button>

  <div class="logout">
     <h3 style="flost:left">
   Welcome <?php echo $_SESSION['username'];?>
    </h3>
  
<div class="bg-img">
  <div class="picnav">
    <div class="topnav">
      <a href="confirmedLogin.php">Home</a>
      <a href="recipes.php">Specials</a>
      <a href="Ingredients.html">Question</a>
      <a href="index.php">Shop Cart</a>
    </div>
  </div>
</div>

<div class="why"  >
  <h1 align="center">WHAT IS HELLO CHEF?</h1>
  <p class="intro" >
    <strong> HelloChief </strong>is a meal delivery service that ships ingredients directly to your door so you can prepare healthy meals every week for you and your family. If you're like many millennials who live off of Trader Joe's frozen meals and nuking bags of frozen vegetables, odds are you either aren't great at cooking or you just don't have time.
<br> <br>
    And speaking of <strong>time</strong>, cooking healthy isn't just about allocating time to cook it. You have to account for meticulous meal-planning, prep time, cooking, and cleaning up afterward.
<br> <br>
It's no wonder we spend so much eating out - myself included!
<br> <br>
A meal delivery service like HelloFresh was designed to deliver you healthy ingredients so you can quickly (and easily) cook delicious and nutritious homemade meals, without all the hassle of planning, shopping, and prepping.
    
     </p>
  </div>
  
  <div class="image-container">
  <div class="text" >WHY HELLO CHIEF</div>
</div>
  
  <div class="reason" style="display:block; font-size:20px">
   <div class="reason-head" style="margin-left:10%;marhin-right:10%">
     <h1>
      Types of meal kit food options
     </h1>
     <p >
       There are four types of meal kits with HelloFresh. I appreciated this flexibility as a vegetarian.
     </p>
   <list >
       <strong><li>Veggie</li></strong>The veggie plan comes with vegetarian recipes with plant-based proteins, grains, and seasonal produce<br>
       <strong><li>Meat & Veggies</li></strong>This classic meal plan has the widest variety of meat, fish, and seasonal produce.<br>
       <strong><li>Family Friendly</li></strong>The Family plan features quick and easy meals with all the YUM-worthy flavor the whole family loves.<br>
       <strong><li>Low Calorie</li></strong>This meal option is for individuals who are watching their calorie intake, and HelloFresh ensures that you'll have a wide selection of dietician-approved meals that are around 650 calories each.<br>
       </list>
     
     
    </div>
  </div>
  
  

<div class="con" style="display:flex;justify-content:space-around;"> <!--code snippets from W3School-->
<div class="flip-card" >
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="meal2.jpg" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back">
      <h1>Fresh</h1> 
      <p>Fresh and affordable</p> 
      <p>Chef-created deliciousness from $7.49 per meal.</p>
    </div>
  </div>
</div>
  
  <div class="flip-card" >
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="meal3.jpg" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back">
      <h1>Quality</h1> 
      <p>The most 5-star reviews</p> 
      <p>Our huge recipe selection wows week after week.</p>
    </div>
  </div>
</div>
  
    <div class="flip-card" >
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="meal4.jpg" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back">
      <h1>Tasty</h1> 
      <p>You Cook</p> 
      <p>Tasty, inspiring meals you're proudto share with the people you love</p>
    </div>
  </div>
</div>
</div>
  
  
  
  <div class="columns">
  <ul class="price">
    <li class="header">Basic</li>
    <li class="grey">$ 9.99 / meal</li>
    <li>Night Delivery</li>
    <li>meal for one</li>
    <li>1 sides</li>
    <li>Veggie</li>
    <li class="grey"><button onclick="location.href='index.php'" type="button" class="button">Add To Cart</button></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header" style="background-color:#4CAF50">Pro</li>
    <li class="grey">$ 24.99 / week</li>
    <li>Morning Deliary</li>
    <li>meal for two</li>
    <li>2 sides</li>
    <li>Veggies & Meat</li>
   <li class="grey"><button onclick="location.href='index.php'" type="button" class="button">Add To Cart</button></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">Premium</li>
    <li class="grey">$ 49.99 / month</li>
    <li>Deliary Anytime</li>
    <li>meal for family</li>
    <li>4 sides</li>
    <li>Veggies & Meat</li>
    <li class="grey"><button onclick="location.href='index.php'" type="button" class="button">Add To Cart</button></li>
  </ul>
</div>
  
  
 <br>
  <br>
  <br>
  <div class="reason">
     <h1 align="center">
       Recyclable packaging
     </h1>
    <p style="margin-left:10%;margin-right:10%;display:block;border-left: 4px solid black;padding-left: 5px;font-size:22px">
      Every week on the same day, you'll get a box on your doorstep with carefully packed ingredients and recipe cards.<br><br><br>

I love that HelloFresh is thinking about its environmental impact which reflects well on the company at large. Your food comes in a sturdy cardboard box that is fully recyclable and has neat cardboard separators to help separate all the ingredients so it's not thrown in there randomly. Plus there are insulated liners too that keep the food cold along with several ice packs to keep your food nice and cold - and the ice pack bags can also be recycled once you separately dispose of the contents of the ice pack.
    </p>
    

  </div>
  
  
  
  
  


  

   <footer class="site-footer" style="height:300px;padding-left:30px">
      <div class="dedew">
        <div class="row">
          <div class="col-sm-12 col-md-6">
            <h6>About</h6>
            <p class="text-justify" style="color:white">Hellochief.com <i>COOK WANTS TO BE SIMPLE </i> is an website that helps people better manage time to cook for family by provide healther and higher quality ingrediants meal.  </p>
          </div>

         

          <div class="col-xs-6 col-md-3">
            <h6>Quick Links</h6>
            <ul class="footer-links">
              <li><a href="home_page.html" style="color:white">About Us</a></li>
              <li><a href="home_page.html" style="color:white">Contact Us</a></li>
              <li><a href="home_page.html" style="color:white">Privacy Policy</a></li>
              
            </ul>
          </div>
        </div>
        <hr>
      </div>
      <div class="dedew">
        <div class="row">
          <div class="col-md-8 col-sm-6 col-xs-12">
            <p class="copyright-text">Copyright &copy; 2020 All Rights Reserved by 
         <a href="#">Hellochief</a>.
            </p>
          </div>

        </div>
      </div>
</footer>
  
  
<script>//code snippets from W3School 
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
  
  
</body>
</html>