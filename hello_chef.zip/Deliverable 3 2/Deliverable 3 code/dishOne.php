<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="home_page.css">
 <style>
   .bg-img{
        background-image: url("background3.jpg");

   }
  
  </style>
</head>
<body>
<img alt="Company logo"src="newLogo.png" style="width:125px;height:125px";>
 
  <form id="form1" name="form1" method="post" action="display.php" style="float:right;margin-top:35px">
<input name="submit" type="image" value="ee" src="user.jpeg" style="height:60px;width:60px;" />
</form>
  
<button onclick="location.href='logout.php'" style="width:auto; position:absolute;right:100px;top:50px;float:right">Log Out</button>

  
<div id="id01" class="modal">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
    
    </div>


  
<div class="bg-img">
  <div class="picnav">
    <div class="topnav">
      <a href="home_page.html">Home</a>
      <a href="recipes.php">Recipes</a>
      <a href="Ingredients.html">Question</a>
      <a href="index.php">Shop Cart</a>
    </div>
  </div>
</div>
  <br><br>
<h1><b>
  Creamy Chicken Pesto Pasta
  </b>  </h1>
  <h3 style="text-align:right;">
    with Steamed Broccoli
  </h3>
  <br>
  <img src="recipes1.jpeg" alt="strps" style="width:50%;height:5%;display:inline;">
    <div class="time" style="display:inline;float:right;margin-right:10%">
 
    
    <p style="font-size:30px;">
      <strong>Ingredients</strong> <br><br>
     <table>
  <tr>
    <td> Penne pasta</td>
    <td>250.00 Grams</td>
  </tr>
  <tr>
    <td>Chicken breast</td>
    <td>400.00 Grams</td>
  </tr>
  <tr>
    <td>Brown onion</td>
    <td>1.00 Pieces</td>
  </tr>
  <tr>
    <td>Garlic cloves</td>
    <td>2.00 Pieces</td>
  </tr>
          <tr>
    <td> Zucchini small</td>
    <td>2.00 Pieces</td>
  </tr>
  <tr>
    <td>Olive oil </td>
    <td> 1.00 Tbsp</td>
  </tr>
  <tr>
    <td>Salt </td>
    <td> 0.50 Tsp</td>
  </tr>
  <tr>
    <td>Green pesto </td>
    <td> 50.00 Grams</td>
  </tr>
         <tr>
    <td>Cream cheese</td>
    <td>80.00 Grams</td>
  </tr>
  <tr>
    <td>Water</td>
    <td> 120.00 ML</td>
  </tr>
  <tr>
    <td>Chicken stock cube</td>
    <td>0.50 Pieces</td>
  </tr>
  <tr>
    <td>Black pepper</td>
    <td>0.50 Tsp</td>
  </tr>

</table>
    </p>
 </div>
  <h1>
    Instructions
  </h1>
  
  
  <div class="first-steps" style="display:flex;justify-content:space-between">
    <img alt="first-step" src="recipes2.jpeg"style="width:20%;height:20%;" >

    <p style="padding-left:200px"><strong>1 Prep</strong><br>
      Slice the chicken into bite-size pieces. Peel and chop the onion. Peel and crush the garlic. Grate the zucchini. Rinse the broccoli and separate it into florets.
     </p>
    </div>
  
    <div class="first-steps" style="display:flex;justify-content:space-between">
    <img alt="first-step" src="recipes3.jpeg"style="width:20%;height:20%;" >

    <p style="padding-left:200px"><strong>2 Boil pasta</strong><br>
    Bring a large pot of salted water to the boil. Once boiling, add the penne and cook for 8-10 min until 'al dente' or cooked to your liking. Drain and reserve a cup of pasta water.
     </p>
    </div>
  
      <div class="first-steps" style="display:flex;justify-content:space-between">
    <img alt="first-step" src="recipes4.jpeg"style="width:20%;height:20%;" >

    <p style="padding-left:200px"><strong>3 Start sauce</strong><br>
    Meanwhile, heat a non-stick pan over a medium-low heat with a drizzle of olive oil. Once hot, add the onion with a pinch of salt and cook for 5-6 min or until softened. Once softened, add the garlic, zucchini and chicken. Cook for 3 min.
     </p>
    </div>
  
  
    <div class="first-steps" style="display:flex;justify-content:space-between">
    <img alt="first-step" src="recipes5.jpeg"style="width:20%;height:20%;" >

    <p style="padding-left:200px"><strong>4 Finish sauce</strong><br>
  Add the green pesto, cream cheese, measured water (preferably the pasta cooking water), chicken stock cube and black pepper. Simmer for 5 min, uncovered.
     </p>
    </div>
  
     <div class="first-steps" style="display:flex;justify-content:space-between">
    <img alt="first-step" src="recipes6.jpeg"style="width:20%;height:20%;" >

    <p style="padding-left:200px"><strong>5 Boil broccoli</strong><br>
 Meanwhile, bring a pot of lightly salted water to a boil. The water should only fill 1/5 of the pot and should not be enough to fully cover the broccoli. Add the broccoli and cover with a lid. Steam for 5 min until tender. Drain.
     </p>
    </div>
  
    <div class="first-steps" style="display:flex;justify-content:space-between">
    <img alt="first-step" src="recipes7.jpeg"style="width:20%;height:20%;" >

    <p style="padding-left:200px"><strong>6 Combine</strong><br>
 Toss the cooked pasta in the chicken sauce. Season to taste. Grate the Parmesan and mix half of it into the pasta. Divide the pasta among plates. Garnish with fresh basil leaves and the remaining Parmesan. Serve the steamed broccoli on the side.
     </p>
    </div>
  
    <br>
  
  <button onclick="location.href='index.php'" style="width:auto; position:absolute;right:700px;">Add To Cart</button>
  <br>
  <br><br><br>
  
  
   <footer class="site-footer" style="height:300px">
      <div class="dedew">
        <div class="row">
          <div class="col-sm-12 col-md-6">
            <h6>About</h6>
            <p class="text-justify">Hellochief.com <i>COOK WANTS TO BE SIMPLE </i> is an website that helps people better manage time to cook for family by provide healther and higher quality ingrediants meal.  </p>
          </div>

         

          <div class="col-xs-6 col-md-3">
            <h6>Quick Links</h6>
            <ul class="footer-links">
              <li><a href="home_page.html">About Us</a></li>
              <li><a href="home_page.html">Contact Us</a></li>
              <li><a href="home_page.html">Privacy Policy</a></li>
              
            </ul>
          </div>
        </div>
        <hr>
      </div>
      <div class="dedew">
        <div class="row">
          <div class="col-md-8 col-sm-6 col-xs-12">
            <p class="copyright-text">Copyright &copy; 2020 All Rights Reserved by 
         <a href="#">Hellochief</a>.
            </p>
          </div>

        </div>
      </div>
</footer>
  


  
  
  
  
  
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
</body>
</html>