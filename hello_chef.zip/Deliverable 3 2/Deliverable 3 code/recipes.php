<?php
session_start();
?>


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="recipes.css">
 <style>
   .bg-img{
        background-image: url("background6.jpg");
 }
   .card1 {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 400px;
  height:570px;
  margin: auto;
  text-align: center;
  font-family: arial;
  float:left;
  margin-left:5%;
     
}

.price {
  color: grey;
  font-size: 22px;
}

.card1 button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card1 button:hover {
  opacity: 0.7;
}
   .countdownContainer{
     position:relative;
     top:50%;
     left:50%;
     transform:translateX(-50%)translateY(-50%);
     text-align:center;
     background:#fff;
     border:1px dolid #999;
     padding:10px;
     box-shadow:0 0 5px 3px #ccc;
     opacity:80%;
     color:red;
   }
   .info{
     font-size:40px;
   }

  </style>
</head>
<body>
<img alt="Company logo"src="newLogo.png" style="width:125px;height:125px";>
 
  
  
  <form id="form1" name="form1" method="post" action="display.php" style="float:right;margin-top:35px">
<input name="submit" type="image" value="ee" src="user.jpeg" style="height:60px;width:60px;" />
</form>
  
<button onclick="location.href='logout.php'" style="width:auto; position:absolute;right:100px;top:50px;float:right">Log Out</button>


  
<div class="bg-img">
  <div class="picnav">
    <div class="topnav">
      <a href="confirmedLogin.php">Home</a>
      <a href="recipes.html">Specials</a>
      <a href="Ingredients.html">Question</a>
      <a href="index.php">Shop Cart</a>
    </div>
  </div>
</div>
  <br><br><br><br>
<table class="countdownContainer">
 <tr class="info">
   <td colspan="4" id="greeting"> Special Offers Starts Now ! </td>
  </tr>
  <tr class="info">
    <td id="days">1</td>
    <td id ="hours">2</td>
    <td id ="minutes">12</td>
    <td id ="seconds">22</td>
  </tr>
  <tr>
    <td>Days</td>
    <td>Hours</td>
    <td>Minutes</td>
    <td>Seconds</td>
  </tr>
  </table>

 
  <div id="container" style="margin-left:0%;float:left;margin-left:4%;position:relative">
			<div id="calculator">
         <h3>
      Calorie calculator
    </h3>
				<div id="result">
					<div id="history">
						<p id="history-value"></p>
					</div>
					<div id="output">
						<p id="output-value"></p>
					</div>
				</div>
				<div id="keyboard">
					<button class="operator" id="clear">C</button>
					<button class="operator" id="backspace">CE</button>
					<button class="operator" id="%">%</button>
					<button class="operator" id="/">&#247;</button>
					<button class="number" id="7">7</button>
					<button class="number" id="8">8</button>
					<button class="number" id="9">9</button>
					<button class="operator" id="*">&times;</button>
					<button class="number" id="4">4</button>
					<button class="number" id="5">5</button>
					<button class="number" id="6">6</button>
					<button class="operator" id="-">-</button>
					<button class="number" id="1">1</button>
					<button class="number" id="2">2</button>
					<button class="number" id="3">3</button>
					<button class="operator" id="+">+</button>
					<button class="empty" id="empty"></button>
					<button class="number" id="0">0</button>
					<button class="empty" id="empty"></button>
					<button class="operator" id="=">=</button>
				</div>
			</div>
		</div>
  <br>
  <br>

  <div class="offer">
   <div class="card1" >
  <img src="recipes1.jpeg" alt="dishOne" style="height:30%;">
  <h1>Creamy Chicken Pesto Pasta</h1>
  <p class="price">$19.99</p>
  <p>Did you know that broccoli contains as much calcium gram per gram as milk?</p>
     <p>
       Cooking Time: 20 min<br>

Cals 1075 <br> Prot 75 <br> Carbs 113 <br> Fat 35
     </p><br>
  <p><button onclick= "location.href='dishOne.php'" >See Recipes</button></p>
</div>
       <div class="card1">
  <img src="head.png" alt="dishTwo" style="height:30%;">
  <h1>Spicy Mongolian Beef</h1>
  <p class="price">$19.99</p><br>
  <p>In this recipe you'll use the time in which your steak is resting, to whip up a quick stir fry!</p>
         <p>
           Cooking Time: 20 min<br>

Cals 433 <br> Prot 51 <br> Carbs 40 <br> Fat 13<br><br><br>

<strong>Dairy-Free</strong>

         </p>
  <p><button onclick= "location.href='dishTwo.php'">See Recipes</button></p>
</div>
  </div>
  
  
  <br><br><br><br> <br><br><br><br> <br><br><br><br> <br><br><br><br>
  <br><br><br><br> <br><br><br><br> <br><br><br><br> 

   <footer class="site-footer" style="height:300px;padding-left:30px">
      <div class="dedew">
        <div class="row">
          <div class="col-sm-12 col-md-6">
            <h6>About</h6>
            <p class="text-justify" style="color:white">Hellochief.com <i>COOK WANTS TO BE SIMPLE </i> is an website that helps people better manage time to cook for family by provide healther and higher quality ingrediants meal.  </p>
          </div>

         

          <div class="col-xs-6 col-md-3">
            <h6>Quick Links</h6>
            <ul class="footer-links">
              <li><a href="home_page.html" style="color:white">About Us</a></li>
              <li><a href="home_page.html" style="color:white">Contact Us</a></li>
              <li><a href="home_page.html" style="color:white">Privacy Policy</a></li>
              
            </ul>
          </div>
        </div>
        <hr>
      </div>
      <div class="dedew">
        <div class="row">
          <div class="col-md-8 col-sm-6 col-xs-12">
            <p class="copyright-text">Copyright &copy; 2020 All Rights Reserved by 
         <a href="#">Hellochief</a>.
            </p>
          </div>

        </div>
      </div>
</footer>
  
  	<script type="text/javascript">
    function getHistory(){
	return document.getElementById("history-value").innerText;
}
function printHistory(num){
	document.getElementById("history-value").innerText=num;
}
function getOutput(){
	return document.getElementById("output-value").innerText;
}
function printOutput(num){
	if(num==""){
		document.getElementById("output-value").innerText=num;
	}
	else{
		document.getElementById("output-value").innerText=getFormattedNumber(num);
	}	
}
function getFormattedNumber(num){
	if(num=="-"){
		return "";
	}
	var n = Number(num);
	var value = n.toLocaleString("en");
	return value;
}
function reverseNumberFormat(num){
	return Number(num.replace(/,/g,''));
}
var operator = document.getElementsByClassName("operator");
for(var i =0;i<operator.length;i++){
	operator[i].addEventListener('click',function(){
		if(this.id=="clear"){
			printHistory("");
			printOutput("");
		}
		else if(this.id=="backspace"){
			var output=reverseNumberFormat(getOutput()).toString();
			if(output){//if output has a value
				output= output.substr(0,output.length-1);
				printOutput(output);
			}
		}
		else{
			var output=getOutput();
			var history=getHistory();
			if(output==""&&history!=""){
				if(isNaN(history[history.length-1])){
					history= history.substr(0,history.length-1);
				}
			}
			if(output!="" || history!=""){
				output= output==""?output:reverseNumberFormat(output);
				history=history+output;
				if(this.id=="="){
					var result=eval(history);
					printOutput(result);
					printHistory("");
				}
				else{
					history=history+this.id;
					printHistory(history);
					printOutput("");
				}
			}
		}
		
	});
}
var number = document.getElementsByClassName("number");
for(var i =0;i<number.length;i++){
	number[i].addEventListener('click',function(){
		var output=reverseNumberFormat(getOutput());
		if(output!=NaN){ //if output is a number
			output=output+this.id;
			printOutput(output);
		}
	});
}
    function countdown(){
      var now = new Date();
      var eventDate  = new Date(2021,6,1);
      var currentTime = now.getTime();
      var eventTime = eventDate.getTime();
      
      var remTime = eventTime - currentTime;
      
      var s = Math.floor(remTime/1000);
      var m = Math.floor(s/60);
      var h = Math.floor(m/60);
      var d = Math.floor(h/60);
      
      h %=24;
      m %= 60;
      s %= 60;
       
      h = (h  <10)?"0"+h:h;
      m = (m  <10)?"0"+m:m;
      s = (s  <10)?"0"+s:s;
      
      document.getElementById("days").textContent = d;
      document.getElementById("days").innerText = d;
      
      document.getElementById("hours").textContent = h;
      document.getElementById("minutes").textContent = m;
      document.getElementById("seconds").textContent = s;
      
      setTimeout(countdown,1000);
      
      if(d<0){
         document.getElementById("greeting").innerHTML = "Special offers Already Finished";
      }
    }
      countdown();
    
    </script>
  
  
  
</body>
</html>