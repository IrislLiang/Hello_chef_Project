<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="home_page.css">
 <style>
   .bg-img{
        background-image: url("background3.jpg");

   }
  
  </style>
</head>
<body>
<img alt="Company logo"src="newLogo.png" style="width:125px;height:125px";>
 
  
   <form id="form1" name="form1" method="post" action="display.php" style="float:right;margin-top:35px">
<input name="submit" type="image" value="ee" src="user.jpeg" style="height:60px;width:60px;" />
</form>
  
<button onclick="location.href='logout.php'" style="width:auto; position:absolute;right:100px;top:50px;float:right">Log Out</button>

<div id="id01" class="modal">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
    
    </div>


  
<div class="bg-img">
  <div class="picnav">
    <div class="topnav">
      <a href="home_page.html">Home</a>
      <a href="recipes.php">Recipes</a>
      <a href="Ingredients.html">Question</a>
      <a href="index.php">Shop Cart</a>
    </div>
  </div>
</div>
  <br><br>
<h1><b>
  Spicy Mongolian Beef
  </b>  </h1>
  <h3 style="text-align:right;">
 Stir Fry
  </h3>
  <br>
  <img src="head.png" alt="strps" style="width:50%;height:5%;display:inline;">
  <div class="time" style="display:inline;float:right;margin-right:10%">
  
    <p style="font-size:30px;">
      <strong>Ingredients</strong> <br><br>
     <table>
  <tr>
    <td> Rump steak </td>
    <td>350.00 Grams</td>
  </tr>
  <tr>
    <td> Chestnut mushrooms </td>
    <td> 250.00 Grams</td>
  </tr>
  <tr>
    <td> White cabbage  </td>
    <td>300.00 Grams</td>
  </tr>
  <tr>
    <td>Red onion </td>
    <td> 1.00 Pieces</td>
  </tr>
          <tr>
    <td> Green chilli small </td>
    <td>2.00 Pieces</td>
  </tr>
  <tr>
    <td>Red chilli small   </td>
    <td> 2.00 Pieces</td>
  </tr>
  <tr>
    <td>Green beans  </td>
    <td> 150.00 Grams</td>
  </tr>
  <tr>
    <td>Vegetable oil</td>
    <td>  2.00 Tbsp</td>
  </tr>
         <tr>
    <td>Bean sprouts </td>
    <td>100.00 Grams</td>
  </tr>
  <tr>
    <td>Sesame seeds  </td>
    <td>  10.00 Grams</td>
  </tr>

</table>
    </p>
 </div>
  
 
  <h1>
    Instructions
  </h1>
  
  
  <div class="first-steps" style="display:flex;justify-content:space-between">
    <img alt="first-step" src="stepOne.png"style="width:20%;height:20%;" >

    <p style="padding-left:200px"><strong>1 Prep vegetables</strong><br>

    Remove the beef steaks from the fridge 20-30 min prior to cooking. Roughly chop the mushrooms and white cabbage. Peel and slice the red onion. Slice the green and red chillis in half lengthwise. Trim the green beans.
    </p>
    </div>
  
    <div class="first-steps" style="display:flex;justify-content:space-between">
    <img alt="first-step" src="stepTwo.png"style="width:20%;height:20%;" >

    <p style="padding-left:200px"><strong>2 Make sauce</strong><br>
In a bowl, whisk together the oyster sauce, soy sauce and brown sugar. Heat a saucepan over a medium heat with a drizzle of vegetable oil. Once hot, add the ginger garlic paste and cook for 1 min. Add the sauce mixture and simmer for 2 min. Remove the pan from the heat, add the ground black pepper and set aside.
      </p>
    </div>
  
      <div class="first-steps" style="display:flex;justify-content:space-between">
    <img alt="first-step" src="stepThree.png"style="width:20%;height:20%;" >

    <p style="padding-left:200px"><strong>3 Fry beef</strong><br>
Pat the steaks dry with kitchen paper. Heat a large pan with a drizzle of vegetable oil over a high heat. Once hot, add the steaks and fry them for 1-3 min on each side or until cooked to your liking. Transfer the steaks to a plate and leave them to rest for 10 min. Once rested, slice finely.
        </p>
    </div>
  
  
    <div class="first-steps" style="display:flex;justify-content:space-between">
    <img alt="first-step" src="stepFour.png"style="width:20%;height:20%;" >

    <p style="padding-left:200px"><strong>4 Fry vegetables</strong><br>
Wipe the pan clean and return it to a high heat with a drizzle of vegetable oil. Add the mushrooms and fry for 4 min. Add the cabbage, green beans, green and red chilli (spicy!) and onion. Fry for 2-3 min further.
      
      </p>
    </div>
  
     <div class="first-steps" style="display:flex;justify-content:space-between">
    <img alt="first-step" src="head.png"style="width:20%;height:20%;" >

    <p style="padding-left:200px"><strong>5 Toss</strong><br>
Add the washed bean sprouts, sliced beef and sauce to the pan and give everything a good mix up. Garnish with sesame seeds and serve immediately.
       </p>
    </div>
  
   <br>
  
  <button onclick="location.href='index.php'" style="width:auto; position:absolute;right:700px;">Add To Cart</button>
  <br>
  <br><br><br>
   <footer class="site-footer" style="height:300px">
      <div class="dedew">
        <div class="row">
          <div class="col-sm-12 col-md-6">
            <h6>About</h6>
            <p class="text-justify">Hellochief.com <i>COOK WANTS TO BE SIMPLE </i> is an website that helps people better manage time to cook for family by provide healther and higher quality ingrediants meal.  </p>
          </div>

         

          <div class="col-xs-6 col-md-3">
            <h6>Quick Links</h6>
            <ul class="footer-links">
              <li><a href="home_page.html">About Us</a></li>
              <li><a href="home_page.html">Contact Us</a></li>
              <li><a href="home_page.html">Privacy Policy</a></li>
              
            </ul>
          </div>
        </div>
        <hr>
      </div>
      <div class="dedew">
        <div class="row">
          <div class="col-md-8 col-sm-6 col-xs-12">
            <p class="copyright-text">Copyright &copy; 2020 All Rights Reserved by 
         <a href="#">Hellochief</a>.
            </p>
          </div>

        </div>
      </div>
</footer>
  


  
  
  
  
  
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
</body>
</html>